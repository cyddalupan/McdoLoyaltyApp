function facebook_add_change_points(totalpoints){
	console.log('facebook_add_change_points');
	totaladdpoints = totaladdpoints + totalpoints;
	return totaladdpoints;
}