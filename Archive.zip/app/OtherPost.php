<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class OtherPost extends Model {

	protected $table = 'other_user_post';

    protected $primaryKey  = 'other_post_id';

}
